﻿--EXPLOTACIÓN DE DATOS DE VULNERABILIDAD DE CONSTRUCCIONES URBANAS

COPY (
select 'Inundación 10' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union


select 'Inundación 50' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union

select 'Inundación 100' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union

select 'Inundación 500' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)order by inundacion, vulnerabilidad asc
) TO 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\TABLAS_CSV\vul_constru_u' DELIMITER',' CSV HEADER;



--EXPLOTACIÓN DE DATOS DE VULNERABILIDAD DE CONSTRUCCIONES RÚSTICAS

COPY (
select 'Inundación 10' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union


select 'Inundación 50' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union

select 'Inundación 100' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union

select 'Inundación 500' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)order by inundacion, vulnerabilidad asc 
) TO 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\TABLAS_CSV\vul_constru_r' DELIMITER',' CSV HEADER;


--EXPLOTACIÓN DE DATOS DE VULNERABILIDAD DE SUBPARCELAS RÚSTICAS

COPY (
select 'Inundación 10' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union


select 'Inundación 50' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_50 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union

select 'Inundación 100' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)
union

select 'Inundación 500' as inundacion, '4' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '3' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '2' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, '1' as Vulnerabilidad, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where Vulnerabilidad = 1 and st_intersects (b.geom, a.geom)order by inundacion, vulnerabilidad asc ) TO 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\TABLAS_CSV\vul_subparce_r' DELIMITER',' CSV HEADER;





--estudios 1

create table analisis.estudios1 as select st_area(geom) from lora.zoninun_10;

--estudios 2

create table analisis.estudios2 as
select count(*) from lora.parce_u a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom);

--estudios 3

create table analisis.estudios3 as
select count(*) from lora.bienin_cat a, lora.parce_u b, lora.zoninun_10 c
where st_intersects(c.geom, b.geom) and a.parcat = b.parcat;

--estudios 4

CREATE table analisis.estudios4 AS (
WITH parce_afectadas AS 
(
SELECT a.parcat, a.geom
FROM lora.parce_u a
INNER JOIN lora.zoninun_10 b
ON st_intersects (a.geom, b.geom)),
 
bienes_afectados AS ( 
SELECT a.parcat, a.geom, b.cod_uso, COUNT (b.refcat) as n_usos
FROM parce_afectadas a, lora.bienin_cat b 
where(a.parcat=b.parcat)
GROUP BY a.parcat, b.cod_uso, a.geom)

SELECT DISTINCT ON (parcat)parcat, cod_uso, geom
FROM bienes_afectados 
ORDER BY parcat DESC, n_usos DESC);

-- estudios 5: Estimación del número de parcelas urbanas afectadas por la inundación según cada uno de los usos principales.

create table analisis.estudios5 as 
select count(cod_uso), cod_uso
from analisis.estudios4
group by cod_uso;

-- estudios 6: Estimación del número total de construcciones urbanas que se verían afectadas por la inundación.

create table analisis.estudios6 as 
select count(*) from lora.constru_u a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom);

--estudios 7: Relación y cartografía (vista espacial) de las construcciones urbanas afectadas por la inundación con alguna superficie construida bajo rasante (sótanos y garajes).

create table analisis.estudios7 as
select a.ninterno, a.constru, a.geom from lora.constru_u a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom) and a.constru like '-%';

--estudios 8: Relación y cartografía de las superficies exactas de parcelas urbanas afectadas por la inundación y superficie afectada de cada una de ellas

create table analisis.estudios8 as
select a.parcat, st_area(a.geom) as areatotal, a.geom, st_area(st_intersection(b.geom, a.geom))/st_area(a.geom)*100 as areaafectada
from lora.parce_u a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom);


--estudios 9; Relación y cartografía de las superficies exactas de las construcciones urbanas afectadas por la inundación y superficie afectada de cada una de ellas

create table analisis.estudios9 as
select a.parcat, st_area(a.geom) as areatotal, a.geom, st_area(st_intersection(b.geom, a.geom)) as areaafectada
from lora.constru_u a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom);

--estudios 10: Estimación del número total de parcelas rústicas que se verían afectadas por la inundación.

create table analisis.estudios10 as
select count(*) as numtotal 
from lora.constru_r a, lora.zoninun_10 b
where st_intersects(b.geom, a.geom);

--estudios 11: Relación de las subparcelas afectadas por la inundación, con indicación del cultivo de cada una de ellas.


create table analisis.estudios11 as
select a.sub_parcat, a.geom, a.tipo
from lora.subparce_r a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom);

--estudios 12: Relación y cartografía de las superficies afectadas por la inundación de cada subparcela rústica y superficie afectada de cada una de ellas

create table analisis.estudios12 as
select a.sub_parcat, a.geom, st_area(a.geom) as superficietotal, st_area(st_intersection(b.geom, a.geom)) as superficieafectada
from lora.subparce_r a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom); 

--estudios 14: Calcula la superficie total de construcciones urbanas y rústicas afectadas por la inundación

create table analisis.estudios14 as
select a.ninterno, st_area(a.geom) as superficietotal, a.geom, 
st_area(st_intersection(b.geom, a.geom))/st_area(a.geom)*100 as supercifieafectada
from lora.constru_u a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom) 
UNION 
select a.ninterno, st_area(a.geom) as superficietotal, a.geom, 
st_area(st_intersection(b.geom, a.geom))/st_area(a.geom)*100 as supercifieafectada
from lora.constru_r a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom);

--estudios 15: Calcula la superficie total de parcelas urbanas y rústicas afectadas por la inundación

create table analisis.estudios15 as
select st_area(a.geom) as superficietotal, a.geom, 
st_area(st_intersection(b.geom, a.geom))/st_area(a.geom)*100 as supercifieafectada
from lora.parce_u a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom) 
UNION 
select st_area(a.geom) as superficietotal, a.geom, 
st_area(st_intersection(b.geom, a.geom))/st_area(a.geom)*100 as supercifieafectada
from lora.parce_r a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom);

--estudios 16: Calcula la superficie total de cada uno de los tipos de cultivos afectados por la inundación

create table analisis.estudios16 as(
with tipocultivo as (
select a.sub_parcat, a.cod_culti, b.cultivo
from lora.subparce_r_cat a, lora.cultivo b
where a.cod_culti = b.cod_culti),
cultivosafectados as(
select sub_parcat, st_area(a.geom) as superficietotal, a.geom, 
st_area(st_intersection(b.geom, a.geom))/st_area(a.geom)*100 as supercifieafectada
from lora.subparce_r a, lora.zoninun_10 b 
where st_intersects(b.geom, a.geom))
select a.sub_parcat, b.geom, a.cultivo, b.supercifieafectada, b.superficietotal from tipocultivo a, cultivosafectados b
where a.sub_parcat = b.sub_parcat);


-- estudios 17 - Recuento de afección construcciones por diversas inundaciones según tipología


select 'Inundación 500' as inundacion, 'Sotanos' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_500 b where a.constru like '-%' and st_intersects(a.geom, b.geom) 
 union
select 'Inundación 500', 'Edificios de una planta' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_500 b where a.constru like 'I' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 500',  'Edificios de dos o más plantas' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_500 b where a.constru like 'II%' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 500', 'Otros' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_500 b where a.constru not like 'I' and a.constru not like '-%' and a.constru not like 'II%' and st_intersects(a.geom, b.geom)

union 

select 'Inundación 100' as inundacion, 'Sotanos' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_100 b where a.constru like '-%' and st_intersects(a.geom, b.geom) 
 union
select 'Inundación 100', 'Edificios de una planta' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_100 b where a.constru like 'I' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 100',  'Edificios de dos o más plantas' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_100 b where a.constru like 'II%' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 100', 'Otros' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_100 b where a.constru not like 'I' and a.constru not like '-%' and a.constru not like 'II%' and st_intersects(a.geom, b.geom) 

union

select 'Inundación 50' as inundacion, 'Sotanos' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_50 b where a.constru like '-%' and st_intersects(a.geom, b.geom) 
 union
select 'Inundación 50', 'Edificios de una planta' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_50 b where a.constru like 'I' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 50',  'Edificios de dos o más plantas' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_50 b where a.constru like 'II%' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 50', 'Otros' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_50 b where a.constru not like 'I' and a.constru not like '-%' and a.constru not like 'II%' and st_intersects(a.geom, b.geom) 

union

select 'Inundación 10' as inundacion, 'Sotanos' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_10 b where a.constru like '-%' and st_intersects(a.geom, b.geom) 
 union
select 'Inundación 10', 'Edificios de una planta' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_10 b where a.constru like 'I' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 10',  'Edificios de dos o más plantas' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_10 b where a.constru like 'II%' and st_intersects(a.geom, b.geom) 
union
select 'Inundación 10', 'Otros' as tipo, count(a.constru) as registros, sum(st_area(a.geom)) as area_construccion, sum(st_area(st_intersection(b.geom,a.geom))) as area_afec, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as supercifieafectada 
from lora.constru_u a, lora.zoninun_10 b where a.constru not like 'I' and a.constru not like '-%' and a.constru not like 'II%' and st_intersects(a.geom, b.geom) order by inundacion, registros
 

-- estudios 18 consulta de uso de construcciones afectadas

select 'Inundación 500' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_500  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso  union 
select 'Inundación 100' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_100  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso union 
select 'Inundación 50' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_50  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso 
union
select 'Inundación 10' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_10  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso 
order by inundacion, uso



--estudios 19. Consulta de subparcelas rústicas 


create schema consulta;

create table consulta.subparce_cultivos_consulta as (SELECT row_number() OVER (ORDER BY a.sub_parcat) AS id, a.parcat,a.tipo, a.geom, b.sub_parcat, b.cod_culti, c.cultivo
FROM lora.subparce_r a inner join lora.subparce_r_cat b inner join lora.cultivo c on (b.cod_culti = c.cod_culti) on a.sub_parcat= b.sub_parcat);

select a.id, a.parcat, a.tipo, a.geom, a.sub_parcat, a.cod_culti, a.cultivo 
from consulta.subparce_cultivos_consulta a, lora.zoninun_500 b
where st_intersects(a.geom, b.geom);

select 'Inundación 500' as inundacion, count(a.cod_culti)as registros, a.cultivo, sum(st_area(a.geom)) as metros_cuadrados_totales, sum(st_area(st_intersection(b.geom, a.geom))) 
as metros_cuadrados_afectados, sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afectado
from consulta.subparce_cultivos_consulta a, lora.zoninun_500 b
where st_intersects(a.geom, b.geom) group by a.cultivo, a.cod_culti union 
select 'Inundación 100' as inundacion, count(a.cod_culti)as registros, a.cultivo, sum(st_area(a.geom)) as metros_cuadrados_totales, sum(st_area(st_intersection(b.geom, a.geom))), sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100
from consulta.subparce_cultivos_consulta a, lora.zoninun_100 b
where st_intersects(a.geom, b.geom) group by a.cultivo, a.cod_culti union 
select 'Inundación 50' as inundacion, count(a.cod_culti)as registros, a.cultivo, sum(st_area(a.geom)) as metros_cuadrados_totales, sum(st_area(st_intersection(b.geom, a.geom))), sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 
from consulta.subparce_cultivos_consulta a, lora.zoninun_50 b
where st_intersects(a.geom, b.geom) group by a.cultivo, a.cod_culti union 
select 'Inundación 10' as inundacion, count(a.cod_culti)as registros, a.cultivo, sum(st_area(a.geom)) as metros_cuadrados_totales, sum(st_area(st_intersection(b.geom, a.geom))), sum(st_area(st_intersection(b.geom, a.geom)))/sum(st_area(a.geom))*100 
from consulta.subparce_cultivos_consulta a, lora.zoninun_10 b
where st_intersects(a.geom, b.geom) group by a.cultivo, a.cod_culti order by inundacion, registros;


select count(a.cod_culti)as registros, a.cod_culti, sum(st_area(a.geom)) as metros_cuadrados 
from analisis.subparce_r_total a, lora.zoninun_500 b
where st_intersects(a.geom, b.geom) group by a.cod_culti order by registros ;



﻿-- PROCESO DE CREACIÓN DE LAS TABLAS DE RIESGO PARA CONSTRUCCIONES RÚSTICAS

/*EN PRIMER LUGAR SE CREA UNA TABLA DE BIENES TOTALES CON EL CÓDIGO DE USO Y LAS CONSTRUCCIONES DE CADA ENTIDAD.
 PARA ELLO:
*/

CREATE TABLE riesgo.subparce_r_total as (SELECT row_number() OVER (ORDER BY a.sub_parcat) AS id, a.parcat,a.tipo, a.geom, b.cod_culti, b.sub_parcat
FROM lora.subparce_r a inner join lora.subparce_r_cat b on (a.sub_parcat= b.sub_parcat));


-- EN SEGUNDO LUGAR ESTOS OBTENEMOS UNA TABLA DE LOS BIENES AFECTADOS POR LAS INUNDACIONES, YA QUE SÓLO ESTOS BIENES SON LOS QUE NOS INTERESAN. PARA ELLO: 

CREATE TABLE riesgo.subparce_r_afectadas_inunda_500 as (
select row_number () over (order by a.sub_parcat), a.parcat, a.tipo, a.geom, a.cod_culti, a.sub_parcat 
from analisis.subparce_r_total a, lora.zoninun_500 b where st_intersects(a.geom, b.geom));

CREATE TABLE riesgo.subparce_r_afectadas_inunda_100 as (
select row_number () over (order by a.sub_parcat), a.parcat, a.tipo, a.geom, a.cod_culti, a.sub_parcat 
from analisis.subparce_r_total a, lora.zoninun_100 b where st_intersects(a.geom, b.geom));

CREATE TABLE riesgo.subparce_r_afectadas_inunda_50 as (
select row_number () over (order by a.sub_parcat), a.parcat, a.tipo, a.geom, a.cod_culti, a.sub_parcat 
from analisis.subparce_r_total a, lora.zoninun_50 b where st_intersects(a.geom, b.geom));

CREATE TABLE riesgo.subparce_r_afectadas_inunda_10 as (
select row_number () over (order by a.sub_parcat), a.parcat, a.tipo, a.geom, a.cod_culti, a.sub_parcat 
from analisis.subparce_r_total a, lora.zoninun_10 b where st_intersects(a.geom, b.geom));



-- EN TERCER LUGAR SE PROCEDE A REALIZAR EL ESTUDIO DE VULNERABILIDAD ASIGNANDO VALORES A LOS USOS Y CONSTRUCCIONES. PARA ELLO: 


select count(cod_culti) as numero_cultivos, cod_culti from analisis.subparce_r_afectadas_inunda_500 group by cod_culti order by numero_cultivos;



create table riesgo.riesgo_subparce_r_inunda_500_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_culti in ('CR','NR','C-','HR','FR','HR', 'O-', 'OR') THEN 4
when cod_culti IN ('VT', 'FF') THEN 3
when cod_culti IN ('E-', 'G','RI','EU','MB') THEN 2
else 1
END as vulnerabilidad, geom
from analisis.subparce_r_afectadas_inunda_500),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom, b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);

create table riesgo.riesgo_subparce_r_inunda_100_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_culti in ('CR','NR','C-','HR','FR','HR', 'O-', 'OR') THEN 4
when cod_culti IN ('VT', 'FF') THEN 3
when cod_culti IN ('E-', 'G','RI','EU','MB') THEN 2
else 1
END as vulnerabilidad, geom
from analisis.subparce_r_afectadas_inunda_100),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom, b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);

create table riesgo.riesgo_subparce_r_inunda_50_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_culti in ('CR','NR','C-','HR','FR','HR', 'O-', 'OR') THEN 4
when cod_culti IN ('VT', 'FF') THEN 3
when cod_culti IN ('E-', 'G','RI','EU','MB') THEN 2
else 1
END as vulnerabilidad, geom
from analisis.subparce_r_afectadas_inunda_50),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom, b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);

create table riesgo.riesgo_subparce_r_inunda_10_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_culti in ('CR','NR','C-','HR','FR','HR', 'O-', 'OR') THEN 4
when cod_culti IN ('VT', 'FF') THEN 3
when cod_culti IN ('E-', 'G','RI','EU','MB') THEN 2
else 1
END as vulnerabilidad, geom
from analisis.subparce_r_afectadas_inunda_10),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom, b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);


﻿--EXPLOTACIÓN DE DATOS DE RIESGO DE CONSTRUCCIONES URBANAS

COPY (
select 'Inundación 10' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 1 and st_intersects (b.geom, a.geom)
union 
select 'Inundación 50' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 1 and st_intersects(b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 1 and st_intersects (b.geom, a.geom)
union 
select 'Inundación 500' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_u_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 1 and st_intersects (b.geom, a.geom) order by inundacion, riesgo asc ) TO 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\TABLAS_CSV\rie_constru_u' DELIMITER',' CSV HEADER;


--EXPLOTACIÓN DE DATOS DE RIESGO DE CONSTRUCCIONES RÚSTICAS

COPY (
select 'Inundación 10' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 1 and st_intersects (b.geom, a.geom)
union 
select 'Inundación 50' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 1 and st_intersects(b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 1 and st_intersects (b.geom, a.geom)
union 
select 'Inundación 500' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_construcciones_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 1 and st_intersects (b.geom, a.geom) order by inundacion, riesgo asc ) TO 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\TABLAS_CSV\rie_constru_r' DELIMITER',' CSV HEADER;



--EXPLOTACIÓN DE DATOS DE RIESGO DE SUBPARCELAS RÚSTICAS

COPY (
select 'Inundación 10' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 10' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_10_tabla a, lora.zoninun_10 b 
where riesgo = 1 and st_intersects (b.geom, a.geom)
union 
select 'Inundación 50' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 50' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_50 b 
where riesgo = 1 and st_intersects(b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_50_tabla a, lora.zoninun_100 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 100' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_100_tabla a, lora.zoninun_100 b 
where riesgo = 1 and st_intersects (b.geom, a.geom)
union 
select 'Inundación 500' as inundacion, 16 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 16 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 12 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 12 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 9 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 9 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 8 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 8 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 6 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 6 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 4 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 4 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 3 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 3 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 2 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 2 and st_intersects (b.geom, a.geom)
union
select 'Inundación 500' as inundacion, 1 as riesgo, count(*)as registros, sum(st_area(a.geom)) as area_total, sum(st_area(st_intersection(b.geom,a.geom))) as area_afectada,
sum(st_area(st_intersection(b.geom,a.geom)))/sum(st_area(a.geom))*100 as porcentaje_afec
from riesgo.riesgo_subparce_r_inunda_500_tabla a, lora.zoninun_500 b 
where riesgo = 1 and st_intersects (b.geom, a.geom) order by inundacion, riesgo asc ) TO 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\TABLAS_CSV\rie_subparce_u' DELIMITER',' CSV HEADER;

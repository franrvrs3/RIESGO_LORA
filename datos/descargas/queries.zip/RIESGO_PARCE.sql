﻿-- PROCESO DE CREACIÓN DE LAS TABLAS DE RIESGO PARA PARCELAS

/*EN PRIMER LUGAR SE CREA UNA TABLA DE BIENES TOTALES CON EL CÓDIGO DE USO Y LAS CONSTRUCCIONES DE CADA ENTIDAD. PARA ELLO:
*/


CREATE TABLE riesgo.parcelas_urbanas_totales as (SELECT DISTINCT ON (b.ninterno)ninterno, row_number() OVER (ORDER BY a.parcat) AS id,a.parcat, b.constru, a.geom, d.cod_uso 
from lora.parce_u a inner join lora.constru_u b inner join lora.parce_u_cat c inner join lora.bienin_cat d on d.parcat= c.parcat on c.parcat = b.parcat on b.parcat = a.parcat );


-- EN SEGUNDO LUGAR ESTOS OBTENEMOS UNA TABLA DE LOS BIENES AFECTADOS POR LAS INUNDACIONES, YA QUE SÓLO ESTOS BIENES SON LOS QUE NOS INTERESAN. PARA ELLO: 

CREATE TABLE riesgo.parcelas_urbanas_afectadas_inunda_500 as (
select row_number () over (order by a.parcat) as gid, a.parcat, a.constru, a.geom, a.cod_uso 
from riesgo.parcelas_urbanas_totales a, lora.zoninun_500 b where st_intersects(a.geom, b.geom));

CREATE TABLE riesgo.parcelas_urbanas_afectadas_inunda_100 as (
select row_number () over (order by a.parcat) as gid, a.parcat, a.constru, a.geom, a.cod_uso 
from riesgo.parcelas_urbanas_totales a, lora.zoninun_100 b where st_intersects(a.geom, b.geom));

CREATE TABLE riesgo.parcelas_urbanas_afectadas_inunda_50 as (
select row_number () over (order by a.parcat) as gid, a.parcat, a.constru, a.geom, a.cod_uso 
from riesgo.parcelas_urbanas_totales a, lora.zoninun_50 b where st_intersects(a.geom, b.geom));

CREATE TABLE riesgo.parcelas_urbanas_afectadas_inunda_10 as (
select row_number () over (order by a.parcat) as gid, a.parcat, a.constru, a.geom, a.cod_uso 
from riesgo.parcelas_urbanas_totales a, lora.zoninun_10 b where st_intersects(a.geom, b.geom));


-- EN TERCER LUGAR SE PROCEDE A REALIZAR EL ESTUDIO DE VULNERABILIDAD ASIGNANDO VALORES A LOS USOS Y CONSTRUCCIONES. PARA ELLO: 


create table riesgo.riesgo_parcelas_u_inunda_500_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_uso='V' and constru NOT LIKE '-%' THEN 3
when cod_uso='V' and constru LIKE '-%' THEN 4
when cod_uso='Y' then 4
when cod_uso IN ('R', 'C', 'E', 'G') THEN 2
else 1
END as vulnerabilidad, geom
from riesgo.parcelas_urbanas_afectadas_inunda_500),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom, b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);


create table riesgo.riesgo_parcelas_u_inunda_100_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_uso='V' and constru NOT LIKE '-%' THEN 3
when cod_uso='V' and constru LIKE '-%' THEN 4
when cod_uso='Y' then 4
when cod_uso IN ('R', 'C', 'E', 'G') THEN 2
else 1
END as vulnerabilidad, geom
from riesgo.parcelas_urbanas_afectadas_inunda_100),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom,
b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);



create table riesgo.riesgo_parcelas_u_inunda_50_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_uso='V' and constru NOT LIKE '-%' THEN 3
when cod_uso='V' and constru LIKE '-%' THEN 4
when cod_uso='Y' then 4
when cod_uso IN ('R', 'C', 'E', 'G') THEN 2
else 1
END as vulnerabilidad, geom
from riesgo.parcelas_urbanas_afectadas_inunda_50),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom,
b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);


create table riesgo.riesgo_parcelas_u_inunda_10_tabla as (
WITH  vulnerabilidad as (
SELECT parcat, CASE
when cod_uso='V' and constru NOT LIKE '-%' THEN 3
when cod_uso='V' and constru LIKE '-%' THEN 4
when cod_uso='Y' then 4
when cod_uso IN ('R', 'C', 'E', 'G') THEN 2
else 1
END as vulnerabilidad, geom
from riesgo.parcelas_urbanas_afectadas_inunda_10),
vul_pel as (
SELECT a.parcat, a.vulnerabilidad, CASE
when st_intersects (a.geom, b.geom) then 4
when st_intersects (a.geom, c.geom) and not st_intersects (a.geom,
b.geom) then 3
when st_intersects (a.geom, d.geom) and not st_intersects (a.geom, c.geom) then 2
when st_intersects (a.geom, e.geom) and not st_intersects (a.geom, d.geom) then 1
END as peligrosidad, a.geom
from vulnerabilidad a, lora.zoninun_10 b, lora.zoninun_50
c, lora.zoninun_100 d, lora.zoninun_500 e)
SELECT row_number () OVER (ORDER BY a.parcat) as gid, a.parcat,
a.vulnerabilidad, a.peligrosidad, a.vulnerabilidad*a.peligrosidad as riesgo,
a.geom
from vul_pel a);


select 'Inundación 500' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_500  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso  union 
select 'Inundación 100' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_100  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso union 
select 'Inundación 50' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_50  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso 
union
select 'Inundación 10' as inundacion, count(d.cod_uso) as registros, e.uso 
from lora.zoninun_10  a
inner join lora.parce_u b
inner join lora.parce_u_cat c 
inner join lora.bienin_cat d 
inner join lora.uso_bien e 
on e.cod_uso = d.cod_uso 
on d.parcat = c.parcat 
on c.parcat = b.parcat 
on st_intersects(b.geom, a.geom) 
group by d.cod_uso, e.uso 
order by inundacion, registros 
;


﻿--Primero importamos los shapefiles que vamos a utilizar así como las tablas alfanuméricas
--En segundo lugar creamos el esquema de trabajo- En este caso lora


--Creación de tabla donde irán los registros del archivo cat

create table lora.importacion_cat_urbano (
importacion_cat_urbano text
); 

/*Tras convertir desde NotePad ++ el archivo Cat a uno plano (txt) se realiza una
 importación a la tabla donde cada registro lineal se inserta en una celda del campo
 importacion_cat_urbano. La ubicación del archivo es la que se muestra, si el archivo 
 cambia de directorio, este también tiene que ser modificado en el código
 
 
 IMPORTANTE: CAMBIAR DIRECTORIO DONDE TENGA ALMACENADO LOS ARCHIVOS CAT*/

copy lora.importacion_cat_urbano 
from 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\CATASTRO\DATOS URB Y RUR\CAT\catastro_urbano.txt' 
with 
encoding 'LATIN1';

create index indicecatur 
on lora.importacion_cat_urbano(importacion_cat_urbano);

-- creación de tablas para nuestro modelo 
/*Previamente a la creación de las tablas modificamos el nombre de los shapefiles
 a importar para que los rusticos y uranos no tengan el mismo nombre y puedan diferenciarse

construcciones_r : construcciones rurales
construcciones_u: construcciones urbanas
masa: manzanas urbanas
parcela_r: parcelas rústicas
parcela_u: parcelas urbanas
subparce: subparcelas 

 */

--se crea tabla manza a partir de una selección

select concat(pcat1, pcat2) 
AS mancat, geom 
into lora.manza 
from lora.masa;

-- creacion de tablas parcelas

select refcat as parcat, 
geom, 
concat(substring
 (pcat1 from 1 for 5), pcat2)
 as mancat
 into lora.parce_u 
 from lora.parcela_u;

 --creación de tabla constru_u

 select id as ninterno, 
 refcat as parcat, 
 constru,
 area,
 geom 
 into lora.constru_u
 from lora.construcciones_u;

 -- creación tabla parce_u_cat

select 
substring(importacion_cat_urbano from 31 for 14) as parcat, 
substring (importacion_cat_urbano from 296 for 10)::numeric as area
into lora.parce_u_cat
from lora.importacion_cat_urbano 
where importacion_cat_urbano like '11%';

--creamos clave primaria

alter table lora.parce_u_cat 
add constraint primparcat
primary key(parcat);

-- Creación BIENIN_CAT bienes_inmuebles

select concat(substring(importacion_cat_urbano from 31 for 14), 
substring(importacion_cat_urbano from 45 for 6)) as refcat, 
substring(importacion_cat_urbano from 31 for 14) as parcat,
substring(importacion_cat_urbano from 372 for 4)::numeric as agno,
substring(importacion_cat_urbano from 428 for 1)as cod_uso
into lora.BIENIN_CAT
from lora.importacion_cat_urbano
where importacion_cat_urbano like '15%';


-- creación tabla uso_bien e importación de archivos a la tabla

create table lora.uso_bien (
cod_uso text, 
uso text
); 

copy lora.uso_bien 
from 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\CATASTRO\DATOS URB Y RUR\usos_bienes_inmuebles.txt'
with delimiter ';';

/*  Ahora vamos a crear los datos para rústico */


-- Importamos los datos de las tablas con postgis


--Creación parce_r 

select refcat as parcat, 
geom, 
tipo
into lora.parce_r 
from lora.parcela_r;

 --creación de tabla constru_r
 
select refcat as parcat, constru, area, geom, id as ninterno
into lora.constru_r
from lora.construcciones_r;

--importamos el cat importacion_cat_rustico

create table lora.importacion_cat_rustico (
importacion_cat_rustico text
);

--copiamos la importación

copy lora.importacion_cat_rustico
from 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\CATASTRO\DATOS URB Y RUR\CAT\catastro_rural.txt' 
with 
encoding 'LATIN1';

 -- Creación tabla de Parce_r_cat

select 
substring(importacion_cat_rustico from 31 for 14) as parcat, 
substring (importacion_cat_rustico from 296 for 10)::numeric as area
into lora.parce_r_cat
from lora.importacion_cat_rustico 
where importacion_cat_rustico like '11%';

--creación tabla subparce_r_cat 

select 
concat(substring(importacion_cat_rustico from 31 for 14),
substring(importacion_cat_rustico from 48 for 1)) as sub_parcat,
substring(importacion_cat_rustico from 31 for 14) as parcat,
substring (importacion_cat_rustico from 66 for 2) as cod_culti
into lora.subparce_r_cat
from lora.importacion_cat_rustico 
where importacion_cat_rustico like '17%';

--creación tabla subparce_r

select geom, concat(refcat, subparce) as sub_parcat, 
refcat as parcat,
tipo 
into lora.subparce_r
from lora.subparce;

--creación tabla cultivo

create table lora.cultivo (
cod_culti text, 
cultivo text
); 


copy lora.cultivo
from 'D:\Users\rivera\Desktop\TFM\CAPAS DEFINITIVAS\CATASTRO\DATOS URB Y RUR\cultivos.txt'
with delimiter ';';

--Creación de índices para cada tabla 

create index parcat_parce_uidx on lora.parce_u(parcat);

create index mancat_parce_u_idx on lora.parce_u(mancat); 

create index pp_idx on lora.parce_u using gist(geom); 

--Indice parcela rustica

create index parcat_parce_r_idx on lora.parce_r(parcat);

create index tipo_parce_r_idx on lora.parce_r(tipo);

create index geom_parce_r_idx on lora.parce_r using gist(geom);

--Indice Manza 

create index mancat_idx on lora.manza(mancat); 

create index geom_manza_idx on lora.manza using gist(geom); 

--Indices Parce_u_cat

create index parce_u_cat_idx on lora.parce_u_cat(parcat);

--Indices constru

create index parcat_constru_uidx on lora.constru_u (parcat);

create index ninterno_constru_u_idx on lora.constru_u (ninterno); 

create index constru_constru_u_idx on lora.constru_u(constru); 

create index geom_constru_u_idx on lora.constru_u using gist(geom);


--Indices uso_bien: solo el código uso

create index uso_bien_idx on lora.uso_bien(cod_uso);

--Indices bienin_cat

create index bienin_cat__idx on lora.bienin_cat(parcat);

create index bienin_cat_refcat_idx on lora.bienin_cat(refcat); 

create index uso_bien_cod_uso_idx on lora.bienin_cat(cod_uso);

-- Indices subparce_r

create index parcat_subparce_uidx on lora.subparce_r(parcat);

create index mancat_subparce_u_idx on lora.subparce_r(sub_parcat); 

create index geom_subparce_idx on lora.subparce_r using gist(geom); 


--Indices constru_r


create index parcat_constru_ridx on lora.constru_r (parcat);

create index ninterno_constru_r_idx on lora.constru_r (ninterno); 

create index constru_constru_r_idx on lora.constru_r(constru); 

create index geom_constru_r_idx on lora.constru_r using gist(geom);

--Incide cultivo 

create index cod_culti_idx on lora.cultivo(cod_culti);


--Indice parce_r_cat

create index parce_r_cat_idx on lora.parce_r_cat(parcat);


-- Indice subparce_r_cat

create index subparce_r_cat_idx on lora.subparce_r_cat(sub_parcat); 

create index subparce_parcat_r_cat_idx on lora.subparce_r_cat(parcat); 


